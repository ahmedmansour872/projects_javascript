# 001 Hey pin menu

In this challenge we are supposed to implement the pin menu (set aside menu) in site hey dot com as follow with the behavior as well not only the design.

![](https://i.imgur.com/VxmbMDO.gif)

## Challenging items

- make a list of contents looks like a stack
- on clicking on that stack expand all items with a curve
- on clicking outside the stack put items down into stack

## More explainations

- if you understand Arabic here is a link for a [youtube video](https://www.youtube.com/watch?v=4TPszCQt8nk) explaining the steps I took to implement that challenge,
- but if you don't understand Arabic don't worry here is a [blog post](https://medhatdawoud.net/blog/cloning-hey-pin-menu) in English which should be helpful in understanding.

## 💻  Happy coding and know on twitter if you need any help in doing that challenge ([@med7atdawoud](http://twitter.com/med7atdawoud)) or just say Hi 👋
