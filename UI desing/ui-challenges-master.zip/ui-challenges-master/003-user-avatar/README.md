# 003 User avatar

In this challenge we need to implement a very small challenge but full of tips as usual, and it should finally look like the following image:

![challenge 003 preview](challenge.png)

## Challenging list

- Create image avatar
- Create User card using the image avatar
- Create Text avatar as a fall back
- implement the random color background and color contrast

## More explanations

- if you understand Arabic here is a link for a [youtube video](#) explaining the steps I took to implement that challenge,

## 💻 Happy coding and know on twitter if you need any help in doing that challenge ([@med7atdawoud](http://twitter.com/med7atdawoud)) or just say Hi 👋
